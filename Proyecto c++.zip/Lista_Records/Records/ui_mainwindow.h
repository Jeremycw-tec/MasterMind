/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.13.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QLabel *label_Nombre2_1;
    QLabel *label_3;
    QLabel *label_Tiempo3_1;
    QLabel *label_Nombre2_3;
    QLabel *label_11;
    QLabel *label_Tiempo2_1;
    QLabel *label_18;
    QLabel *label_4;
    QLabel *label_12;
    QLabel *label_15;
    QLabel *label_7;
    QLabel *label_13;
    QLabel *label_Tiempo1_2;
    QLabel *label_14;
    QLabel *label_5;
    QLabel *label_Nombre1_1;
    QLabel *label_10;
    QLabel *label_Tiempo1_3;
    QLabel *label_Nombre3_1;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_Nombre3_2;
    QLabel *label_8;
    QLabel *label_Nombre2_2;
    QLabel *label_6;
    QLabel *label_Tiempo1_1;
    QLabel *label_Tiempo3_3;
    QLabel *label_9;
    QLabel *label_Nombre3_3;
    QLabel *label_17;
    QLabel *label_Nombre1_2;
    QLabel *label_Tiempo2_2;
    QLabel *label_16;
    QLabel *label_Tiempo3_2;
    QLabel *label_Tiempo2_3;
    QLabel *label_Nombre1_3;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(333, 444);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(10, 10, 93, 28));
        label_Nombre2_1 = new QLabel(centralwidget);
        label_Nombre2_1->setObjectName(QString::fromUtf8("label_Nombre2_1"));
        label_Nombre2_1->setGeometry(QRect(60, 220, 161, 16));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(40, 380, 16, 21));
        label_Tiempo3_1 = new QLabel(centralwidget);
        label_Tiempo3_1->setObjectName(QString::fromUtf8("label_Tiempo3_1"));
        label_Tiempo3_1->setGeometry(QRect(230, 340, 55, 16));
        label_Nombre2_3 = new QLabel(centralwidget);
        label_Nombre2_3->setObjectName(QString::fromUtf8("label_Nombre2_3"));
        label_Nombre2_3->setGeometry(QRect(60, 260, 161, 16));
        label_11 = new QLabel(centralwidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(70, 170, 121, 16));
        label_Tiempo2_1 = new QLabel(centralwidget);
        label_Tiempo2_1->setObjectName(QString::fromUtf8("label_Tiempo2_1"));
        label_Tiempo2_1->setGeometry(QRect(230, 220, 55, 16));
        label_18 = new QLabel(centralwidget);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(60, 320, 61, 16));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(40, 100, 16, 21));
        label_12 = new QLabel(centralwidget);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(70, 290, 121, 16));
        label_15 = new QLabel(centralwidget);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(230, 80, 55, 16));
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(40, 240, 16, 21));
        label_13 = new QLabel(centralwidget);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(230, 320, 55, 16));
        label_Tiempo1_2 = new QLabel(centralwidget);
        label_Tiempo1_2->setObjectName(QString::fromUtf8("label_Tiempo1_2"));
        label_Tiempo1_2->setGeometry(QRect(230, 120, 55, 16));
        label_14 = new QLabel(centralwidget);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(230, 200, 55, 16));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(40, 220, 16, 21));
        label_Nombre1_1 = new QLabel(centralwidget);
        label_Nombre1_1->setObjectName(QString::fromUtf8("label_Nombre1_1"));
        label_Nombre1_1->setGeometry(QRect(60, 100, 161, 16));
        label_10 = new QLabel(centralwidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(70, 50, 121, 16));
        label_Tiempo1_3 = new QLabel(centralwidget);
        label_Tiempo1_3->setObjectName(QString::fromUtf8("label_Tiempo1_3"));
        label_Tiempo1_3->setGeometry(QRect(230, 140, 55, 16));
        label_Nombre3_1 = new QLabel(centralwidget);
        label_Nombre3_1->setObjectName(QString::fromUtf8("label_Nombre3_1"));
        label_Nombre3_1->setGeometry(QRect(60, 340, 161, 16));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 340, 20, 20));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 360, 16, 21));
        label_Nombre3_2 = new QLabel(centralwidget);
        label_Nombre3_2->setObjectName(QString::fromUtf8("label_Nombre3_2"));
        label_Nombre3_2->setGeometry(QRect(60, 360, 161, 16));
        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(40, 140, 16, 21));
        label_Nombre2_2 = new QLabel(centralwidget);
        label_Nombre2_2->setObjectName(QString::fromUtf8("label_Nombre2_2"));
        label_Nombre2_2->setGeometry(QRect(60, 240, 161, 16));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(40, 120, 16, 21));
        label_Tiempo1_1 = new QLabel(centralwidget);
        label_Tiempo1_1->setObjectName(QString::fromUtf8("label_Tiempo1_1"));
        label_Tiempo1_1->setGeometry(QRect(230, 100, 55, 16));
        label_Tiempo3_3 = new QLabel(centralwidget);
        label_Tiempo3_3->setObjectName(QString::fromUtf8("label_Tiempo3_3"));
        label_Tiempo3_3->setGeometry(QRect(230, 380, 55, 16));
        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(40, 260, 16, 21));
        label_Nombre3_3 = new QLabel(centralwidget);
        label_Nombre3_3->setObjectName(QString::fromUtf8("label_Nombre3_3"));
        label_Nombre3_3->setGeometry(QRect(60, 380, 161, 16));
        label_17 = new QLabel(centralwidget);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(60, 80, 61, 16));
        label_Nombre1_2 = new QLabel(centralwidget);
        label_Nombre1_2->setObjectName(QString::fromUtf8("label_Nombre1_2"));
        label_Nombre1_2->setGeometry(QRect(60, 120, 161, 16));
        label_Tiempo2_2 = new QLabel(centralwidget);
        label_Tiempo2_2->setObjectName(QString::fromUtf8("label_Tiempo2_2"));
        label_Tiempo2_2->setGeometry(QRect(230, 240, 55, 16));
        label_16 = new QLabel(centralwidget);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(60, 200, 61, 16));
        label_Tiempo3_2 = new QLabel(centralwidget);
        label_Tiempo3_2->setObjectName(QString::fromUtf8("label_Tiempo3_2"));
        label_Tiempo3_2->setGeometry(QRect(230, 360, 55, 16));
        label_Tiempo2_3 = new QLabel(centralwidget);
        label_Tiempo2_3->setObjectName(QString::fromUtf8("label_Tiempo2_3"));
        label_Tiempo2_3->setGeometry(QRect(230, 260, 55, 16));
        label_Nombre1_3 = new QLabel(centralwidget);
        label_Nombre1_3->setObjectName(QString::fromUtf8("label_Nombre1_3"));
        label_Nombre1_3->setGeometry(QRect(60, 140, 161, 16));
        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Generar PDF", nullptr));
        label_Nombre2_1->setText(QString());
        label_3->setText(QCoreApplication::translate("MainWindow", "3-", nullptr));
        label_Tiempo3_1->setText(QString());
        label_Nombre2_3->setText(QString());
        label_11->setText(QCoreApplication::translate("MainWindow", "TOP-3: NIVEL MEDIO", nullptr));
        label_Tiempo2_1->setText(QString());
        label_18->setText(QCoreApplication::translate("MainWindow", "JUGADOR", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "1-", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "TOP-3: NIVEL FACIL", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "TIEMPO", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "2-", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "TIEMPO", nullptr));
        label_Tiempo1_2->setText(QString());
        label_14->setText(QCoreApplication::translate("MainWindow", "TIEMPO", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "1-", nullptr));
        label_Nombre1_1->setText(QString());
        label_10->setText(QCoreApplication::translate("MainWindow", "TOP-3: NIVEL DIF\303\215CIL", nullptr));
        label_Tiempo1_3->setText(QString());
        label_Nombre3_1->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "1-", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "2-", nullptr));
        label_Nombre3_2->setText(QString());
        label_8->setText(QCoreApplication::translate("MainWindow", "3-", nullptr));
        label_Nombre2_2->setText(QString());
        label_6->setText(QCoreApplication::translate("MainWindow", "2-", nullptr));
        label_Tiempo1_1->setText(QString());
        label_Tiempo3_3->setText(QString());
        label_9->setText(QCoreApplication::translate("MainWindow", "3-", nullptr));
        label_Nombre3_3->setText(QString());
        label_17->setText(QCoreApplication::translate("MainWindow", "JUGADOR", nullptr));
        label_Nombre1_2->setText(QString());
        label_Tiempo2_2->setText(QString());
        label_16->setText(QCoreApplication::translate("MainWindow", "JUGADOR", nullptr));
        label_Tiempo3_2->setText(QString());
        label_Tiempo2_3->setText(QString());
        label_Nombre1_3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
