#include "calificacion.h"

Calificacion::Calificacion()
{

}
