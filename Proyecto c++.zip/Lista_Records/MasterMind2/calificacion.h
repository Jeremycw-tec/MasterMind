#ifndef CALIFICACION_H
#define CALIFICACION_H


class Calificacion
{
public:
    Calificacion();
};

#endif // CALIFICACION_H
